#include "ghosts.h"

Ghost::Ghost(){
    Point p;
    Color c;
    pos = p;
    color = c;
    dir = UP;


}
Ghost::Ghost(Point p, Color c, Point aPos){
    pos = p;
    arrPos = aPos;
    color = c;
    dir = UP;


}

bool Ghost::move(int dir, const int oriDir, SDL_Plotter& g){

    //if UP
    if(dir == 3 && oriDir != 2){
        if(gMap.tMap[arrPos.x][arrPos.y - 1]){
            exit(1);
            arrPos.y = arrPos.y -1;
            for(int j = 0; j < 24; j++){
                erase(g);
                pos.y-=1;
                draw(g);
                g.update();
            }
        }
        else{
            dir = 0;
            move(dir, oriDir, g);
        }
    }


    return true;
}

void Ghost::target(const Point& p)const{


return;
}

void Ghost::draw(SDL_Plotter& g)const{
    for(int i = 0; i < 24; i++){
            for(int k = 0; k < 24; k++){
                g.plotPixel(pos.x+i,pos.y+k,color.R,color.G,color.B);
            }
    }

}
void Ghost::erase(SDL_Plotter& g)const{
    for(int i = 0; i < 24; i++){
            for(int k = 0; k < 24; k++){
                g.plotPixel(pos.x+i,pos.y+k,255,255,255);
            }
    }

}
