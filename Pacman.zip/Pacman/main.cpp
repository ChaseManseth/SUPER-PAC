#include <iostream>
#include <fstream>
#include <iomanip>
#include "SDL_Plotter.h"
#include "ghosts.h"

using namespace std;

int main(int argc, char ** argv)
{
    ofstream output;
    output.open("output.txt");
    SDL_Plotter g(1000,1000);
    int x,y, aX, aY;
    int R,G,B;
    aX = 6;
    aY = 15;
    x = y = 100;
    R = 200, G = 20, B = 20;
    Point p(x,y);
    Point aP(aY,aX);
    Color c(R,G,B);
    Ghost Blinky(p, c, aP);
    int dir = 3;


    /*
    for(int r = 0; r < 36; r++){
        for(int c = 0; c < 28; c++){
            output << "(" << setw(2) << r << "," << setw(2) << c << ") ";
        }
        output << endl << endl;
    }
    */

    while(!g.getQuit())
    {
        Blinky.move(dir,dir,g);
        g.update();
    	if(g.kbhit()){
    	    g.getKey();
    	}
    }
}
