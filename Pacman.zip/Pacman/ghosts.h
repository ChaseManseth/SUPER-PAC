#ifndef GHOSTS_H_INCLUDED
#define GHOSTS_H_INCLUDED

#include "map.h"
#include "SDL_Plotter.h"
#include <cstdlib>

using namespace std;

const int LEFT = 0;
const int RIGHT = 1;
const int DOWN = 2;
const int UP = 3;


struct Point{
    int x, y;
    Point(){
    x = y = 0;
    }
    Point(int a, int b){
    x = a;
    y = b;
    }

};
struct Color{
    int R, G, B;
    Color(){
    R = G = B = 0;
    }
    Color(int r, int g, int b){
    R = r;
    G = g;
    B = b;
    }
};

class Ghost{
    private:
        Map gMap;
        bool active;
        Point pos;
        Point arrPos;
        int dir;
        bool scatter;
        Color color;
    public:
        Ghost();
        Ghost(Point , Color , Point);

        bool move(int dir, const int oriDir, SDL_Plotter& g);
        void target(const Point& )const;
        void go()const;
        void draw(SDL_Plotter& )const;
        void erase(SDL_Plotter& )const;
};

#endif // GHOSTS_H_INCLUDED
